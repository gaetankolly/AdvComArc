#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  3 13:22:17 2022

@author: ga
"""

import serverModule


def main():
    serverModule.startServer()

if __name__ == '__main__':
    main();
   

