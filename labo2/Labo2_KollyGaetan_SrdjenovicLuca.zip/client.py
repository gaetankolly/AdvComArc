#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  3 13:29:36 2022

@author: ga
"""

import clientModule


def main():
    clientModule.startCient()

if __name__ == '__main__':
    main();
   
